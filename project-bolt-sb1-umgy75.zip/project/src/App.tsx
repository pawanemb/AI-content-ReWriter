import React, { useState } from 'react';
import { analyzeWithGPT, rewriteWithGPT, type ContentAnalysis } from './utils/openai';
import { ContentSection } from './components/ContentSection';
import { SuggestionsList } from './components/SuggestionsList';

function App() {
  const [originalContent, setOriginalContent] = useState('');
  const [rewrittenContent, setRewrittenContent] = useState('');
  const [originalScores, setOriginalScores] = useState<ContentAnalysis | null>(null);
  const [rewrittenScores, setRewrittenScores] = useState<ContentAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    try {
      setLoading(true);
      setError(null);
      const scores = await analyzeWithGPT(originalContent);
      setOriginalScores(scores);
    } catch (err) {
      setError('Failed to analyze content. Please check your API key and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRewrite = async () => {
    try {
      setLoading(true);
      setError(null);
      const improved = await rewriteWithGPT(originalContent);
      setRewrittenContent(improved);
      const scores = await analyzeWithGPT(improved);
      setRewrittenScores(scores);
    } catch (err) {
      setError('Failed to rewrite content. Please check your API key and try again.');
    } finally {
      setLoading(false);
    }
  };

  const suggestions = originalScores?.suggestions || rewrittenScores?.suggestions || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            AI-Powered Content Optimizer
          </h1>
          <p className="text-gray-600">
            Analyze and improve your content with ChatGPT
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          <ContentSection
            title="Original Content"
            content={originalContent}
            scores={originalScores}
            isEditable={true}
            loading={loading}
            onContentChange={setOriginalContent}
            onAnalyze={handleAnalyze}
            onRewrite={handleRewrite}
          />

          <ContentSection
            title="Optimized Content"
            content={rewrittenContent}
            scores={rewrittenScores}
          />
        </div>

        <SuggestionsList suggestions={suggestions} />
      </div>
    </div>
  );
}

export default App;