import React from 'react';

interface ScoreDisplayProps {
  label: string;
  score: number;
}

export function ScoreDisplay({ label, score }: ScoreDisplayProps) {
  const displayScore = Math.round(Number(score) || 0);
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };
  
  return (
    <div className="bg-gray-50 p-4 rounded-lg">
      <div className="text-sm text-gray-600">{label}</div>
      <div className={`text-2xl font-bold ${getScoreColor(displayScore)}`}>
        {displayScore}
      </div>
    </div>
  );
}