import React from 'react';
import { BarChart2, Loader2, Wand2 } from 'lucide-react';
import { ContentAnalysis } from '../utils/openai';
import { ScoreDisplay } from './ScoreDisplay';

interface ContentSectionProps {
  title: string;
  content: string;
  scores: ContentAnalysis | null;
  isEditable?: boolean;
  loading?: boolean;
  onContentChange?: (content: string) => void;
  onAnalyze?: () => void;
  onRewrite?: () => void;
}

export function ContentSection({
  title,
  content,
  scores,
  isEditable = false,
  loading = false,
  onContentChange,
  onAnalyze,
  onRewrite,
}: ContentSectionProps) {
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-lg font-semibold text-gray-800 mb-4">{title}</h2>
        <textarea
          className={`w-full h-64 p-4 border rounded-lg ${
            isEditable
              ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent'
              : 'bg-gray-50'
          }`}
          placeholder={isEditable ? 'Paste your content here...' : 'Optimized content will appear here...'}
          value={content}
          onChange={(e) => onContentChange?.(e.target.value)}
          readOnly={!isEditable}
        />
        {isEditable && onAnalyze && onRewrite && (
          <div className="flex gap-3 mt-4">
            <button
              onClick={onAnalyze}
              disabled={loading || !content}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <BarChart2 className="w-4 h-4" />
              )}
              Analyze
            </button>
            <button
              onClick={onRewrite}
              disabled={loading || !content}
              className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Wand2 className="w-4 h-4" />
              )}
              Rewrite
            </button>
          </div>
        )}
      </div>

      {scores && (
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            {isEditable ? 'Original Scores' : 'Improved Scores'}
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <ScoreDisplay label="Readability" score={scores.readability} />
            <ScoreDisplay label="SEO Score" score={scores.seoScore} />
            <ScoreDisplay label="Engagement" score={scores.engagement} />
            <ScoreDisplay label="Total Score" score={scores.totalScore} />
          </div>
        </div>
      )}
    </div>
  );
}