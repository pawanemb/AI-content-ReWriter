import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export interface ContentAnalysis {
  readability: number;
  seoScore: number;
  engagement: number;
  totalScore: number;
  suggestions: string[];
}

const validateScores = (analysis: any): ContentAnalysis => {
  const scores = {
    readability: Math.round(Number(analysis?.readability || analysis?.scores?.readability || 0)),
    seoScore: Math.round(Number(analysis?.seoScore || analysis?.scores?.seo || 0)),
    engagement: Math.round(Number(analysis?.engagement || analysis?.scores?.engagement || 0)),
    suggestions: Array.isArray(analysis?.suggestions) ? analysis.suggestions : []
  };

  scores.totalScore = Math.round((scores.readability + scores.seoScore + scores.engagement) / 3);

  return scores;
};

export const analyzeWithGPT = async (text: string): Promise<ContentAnalysis> => {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are a content analysis expert. Analyze the given text and provide scores and suggestions.
          Return a JSON object with this exact structure:
          {
            "scores": {
              "readability": number (0-100),
              "seo": number (0-100),
              "engagement": number (0-100)
            },
            "suggestions": string[]
          }`
        },
        {
          role: "user",
          content: `Analyze this text and provide scores (0-100) and suggestions: "${text}"`
        }
      ],
      response_format: { type: "json_object" }
    });

    const rawAnalysis = JSON.parse(response.choices[0].message.content);
    return validateScores(rawAnalysis);
  } catch (error) {
    console.error('Error analyzing content:', error);
    throw error;
  }
};

export const rewriteWithGPT = async (text: string): Promise<string> => {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are a professional content rewriter. Improve the given text by:
          - Making it more engaging and clearer
          - Optimizing for SEO
          - Maintaining the original meaning
          - Using active voice
          - Including relevant keywords naturally
          Return only the rewritten text without any explanations.`
        },
        {
          role: "user",
          content: `Rewrite this text: "${text}"`
        }
      ]
    });

    return response.choices[0].message.content.trim();
  } catch (error) {
    console.error('Error rewriting content:', error);
    throw error;
  }
};