interface RewriteRules {
  pattern: RegExp;
  replacement: string | ((match: string) => string);
}

const commonTransitions = [
  'Additionally,',
  'Furthermore,',
  'Moreover,',
  'In addition,',
  'Consequently,',
  'As a result,',
  'Therefore,',
  'Thus,',
  'Hence,',
];

const powerWords = [
  ['good', 'excellent'],
  ['bad', 'problematic'],
  ['big', 'substantial'],
  ['small', 'compact'],
  ['important', 'crucial'],
  ['interesting', 'fascinating'],
] as const;

export const rewriteContent = (text: string): string => {
  if (!text.trim()) return '';

  // Split into sentences
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  // Process each sentence
  const improved = sentences.map((sentence, index) => {
    let enhanced = sentence.trim();

    // Add transitions for flow (but not to first sentence)
    if (index > 0 && !enhanced.match(/^(however|furthermore|moreover|therefore|thus|hence)/i)) {
      if (Math.random() < 0.3) {
        enhanced = `${commonTransitions[Math.floor(Math.random() * commonTransitions.length)]} ${enhanced}`;
      }
    }

    // Replace weak words with power words
    powerWords.forEach(([weak, strong]) => {
      const regex = new RegExp(`\\b${weak}\\b`, 'gi');
      enhanced = enhanced.replace(regex, strong);
    });

    // Improve sentence structure
    enhanced = enhanced
      // Convert passive to active voice where possible
      .replace(/\b(?:is|are|was|were)\s+being\s+(\w+)ed\b/gi, 'actively $1')
      .replace(/\b(?:is|are|was|were)\s+(\w+)ed\b/gi, '$1s')
      
      // Remove redundant words
      .replace(/\b(?:basically|actually|literally)\s+/gi, '')
      
      // Enhance clarity
      .replace(/\b(?:many|several)\s+/gi, 'numerous ')
      .replace(/\b(?:show|demonstrate)\b/gi, 'illustrate')
      .replace(/\b(?:help|assist)\b/gi, 'facilitate');

    return enhanced;
  });

  // Join sentences back together
  return improved.join(' ');
};