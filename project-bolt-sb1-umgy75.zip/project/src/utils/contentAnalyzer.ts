interface AnalysisScore {
  readability: number;
  seoScore: number;
  engagement: number;
  totalScore: number;
}

export const analyzeContent = (text: string): AnalysisScore => {
  // Calculate readability (based on sentence length and complexity)
  const sentences = text.split(/[.!?]+/).filter(Boolean);
  const words = text.split(/\s+/).filter(Boolean);
  const avgWordsPerSentence = words.length / sentences.length;
  const readability = Math.max(0, Math.min(100, 100 - (avgWordsPerSentence - 15) * 5));

  // Calculate SEO score (keyword density and length)
  const wordFreq = new Map();
  words.forEach(word => {
    wordFreq.set(word.toLowerCase(), (wordFreq.get(word.toLowerCase()) || 0) + 1);
  });
  const keywordDensity = Math.max(...Array.from(wordFreq.values())) / words.length;
  const seoScore = Math.max(0, Math.min(100, 
    (words.length >= 300 ? 50 : words.length / 6) +
    (keywordDensity <= 0.03 ? 50 : 100 - keywordDensity * 1000)
  ));

  // Calculate engagement score
  const engagement = Math.max(0, Math.min(100,
    (text.includes('?') ? 20 : 0) +
    (sentences.some(s => s.includes('!')) ? 20 : 0) +
    (words.length >= 200 ? 30 : words.length / 6.67) +
    (sentences.length >= 10 ? 30 : sentences.length * 3)
  ));

  const totalScore = Math.round((readability + seoScore + engagement) / 3);

  return {
    readability: Math.round(readability),
    seoScore: Math.round(seoScore),
    engagement: Math.round(engagement),
    totalScore
  };
};

export const suggestImprovements = (score: AnalysisScore): string[] => {
  const suggestions: string[] = [];

  if (score.readability < 70) {
    suggestions.push('Try using shorter sentences and simpler words to improve readability');
  }
  if (score.seoScore < 70) {
    suggestions.push('Add more relevant keywords and aim for 300-500 words for better SEO');
  }
  if (score.engagement < 70) {
    suggestions.push('Include questions and engaging elements to boost reader interaction');
  }

  return suggestions;
};